# GitHub Workflow Setup

Repositori ini mempunyai dua GitHub Actions workflow:

- `CI - Test and Build` (`.github/workflows/ci.yml`): berjalan apabila ada push atau pull request ke `main`/`master`. Ia memasang dependencies, menjalankan test, lint dan build.
- `Deploy to Firebase Hosting` (`.github/workflows/firebase-hosting.yml`): berjalan apabila ada push ke `main` atau apabila dijalankan secara manual. Jika semua langkah berjaya, ia deploy laman ke Firebase Hosting.

## 1. Upload projek ke GitHub

1. Extract ZIP ini.
2. Cipta repository di GitHub.
3. Upload semua fail dan folder projek, termasuk folder tersembunyi `.github`.
4. Pastikan branch utama bernama `main`.

## 2. Tetapkan GitHub Actions Secrets

Buka **GitHub repository → Settings → Secrets and variables → Actions → New repository secret** dan tambah:

| Secret name | Value |
|---|---|
| `VITE_FIREBASE_API_KEY` | Firebase Web App API key |
| `VITE_FIREBASE_AUTH_DOMAIN` | Contoh: `online-feedback-cafeteria.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | `online-feedback-cafeteria` |
| `VITE_FIREBASE_STORAGE_BUCKET` | Nilai Storage bucket daripada Firebase Console |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Firebase messaging sender ID |
| `VITE_FIREBASE_APP_ID` | Firebase Web App app ID |
| `FIREBASE_SERVICE_ACCOUNT_ONLINE_FEEDBACK_CAFETERIA` | Kandungan JSON service account untuk projek Firebase |

Jangan letakkan service account JSON atau fail `.env` dalam repository. Jangan kongsi service account key secara terbuka.

## 3. Sediakan Firebase service account

1. Buka Firebase Console / Google Cloud Console untuk projek `online-feedback-cafeteria`.
2. Cipta service account yang mempunyai kebenaran yang diperlukan untuk deploy Firebase Hosting.
3. Jana key JSON dan salin **keseluruhan kandungan JSON** ke secret `FIREBASE_SERVICE_ACCOUNT_ONLINE_FEEDBACK_CAFETERIA`.
4. Aktifkan Firebase Hosting untuk projek itu jika belum aktif.

## 4. Cara workflow berfungsi

`git push` ke `main` → GitHub Actions install dependencies → `npm test` → `npm run lint` → `npm run build` → deploy Firebase Hosting.

Jika ujian, lint atau build gagal, deployment tidak akan diteruskan.

## Nota penting

- Projek Firebase yang digunakan dalam konfigurasi sekarang ialah `online-feedback-cafeteria`. Tukar `projectId` dalam `firebase-hosting.yml` jika anda mahu deploy ke projek lain.
- Firebase Web App config digunakan oleh frontend dan bukan pengganti kepada Firestore/Storage security rules. Semak `firestore.rules` dan `storage.rules` sebelum sistem digunakan secara sebenar.
- Workflow ini deploy **Firebase Hosting sahaja**. Cloud Functions, Firestore rules dan Storage rules tidak dideploy oleh workflow ini.
- Pastikan nama branch di GitHub ialah `main` untuk auto-deploy. CI menyokong `main` dan `master`.

# Cara Upload Projek Lengkap ke GitHub

**Penting:** Jangan upload fail `README` sahaja. ZIP ini mengandungi keseluruhan source code website dan fail workflow.

1. Download ZIP ini.
2. Klik kanan ZIP dan pilih **Extract All**.
3. Buka folder `online-feedback-and-sugestion-system-for-cafeteria-at-tvet-mara-besut-main`.
4. Pergi ke GitHub dan cipta repository baharu.
5. Dalam folder projek di komputer, pilih semua fail dan folder di dalam folder itu. Pastikan folder `src`, `public`, fail `package.json`, `package-lock.json`, dan folder `.github` turut dipilih.
6. Drag semua fail/folder tersebut ke halaman **GitHub → Add file → Upload files**.
7. Klik **Commit changes**.

## Workflow ini buat apa?
Fail `.github/workflows/workflow.yml` akan berjalan setiap kali anda push ke `main`/`master`, buka pull request, atau tekan **Run workflow** pada tab Actions. Ia akan:
- install dependencies dengan `npm ci`
- jalankan ujian menggunakan `npm test`
- periksa kod dengan `npm run lint`
- build website menggunakan `npm run build`
- simpan folder `dist` sebagai artifact untuk dimuat turun daripada hasil workflow

Workflow ini menjalankan test dan build sahaja; ia tidak deploy website secara automatik. Untuk mengaktifkannya, pastikan fail workflow berada di laluan tepat `.github/workflows/workflow.yml` dalam repository GitHub.
